+ **Code Execution:  **
1) The following commands can be used to execute the code:
```
lex proj.l
yacc -d -v proj1.y
gcc lex.yy.c y.tab.c -lm -w
a.exe
