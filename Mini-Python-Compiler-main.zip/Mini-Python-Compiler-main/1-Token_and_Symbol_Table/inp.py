a=10
b=9
c=a+b+100
e=10
f=8
d=e*f
if(a>=b):
	a=a+b
	g=e*f*100

u=10
j=99
