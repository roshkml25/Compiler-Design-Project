+ **Code Execution:  **
1) The following commands can be used to execute the code:
```
python final.py
```

2) Now for checking syntax error and semantics error, refer to Project_Report.pdf, for executing it go to first folder i.e,Token and symbol Table, then make changes in inp.py file according to written in report and execute following commands:
 + **Code Execution:  **
The following commands can be used to execute the code:
```
lex proj.l
yacc -d -v proj1.y
gcc lex.yy.c y.tab.c -lm -w
a.exe
```
